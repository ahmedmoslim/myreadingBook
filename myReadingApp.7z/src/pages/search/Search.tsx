import React from 'react'
import SearchBar from '../../components/searchbar/SearchBar';
export const Search = () => {
    
    return(
        <SearchBar></SearchBar>
    )
}